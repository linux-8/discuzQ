<?php


// 禁止以下文件上传
$this->notallowed = [
    'php',
    'php3',
    'asp',
    'jsp',
    'jspx',
    'aspx',
    'exe',
    'sh',
    'phtml',
];

// 允许远程下载文件扩展名
$this->down_file_ext = [
    'jpg',
    'jpeg',
    'gif',
    'png',
    'webp',
    'zip',
    'aaa',
];