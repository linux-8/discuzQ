<?php

/**
 * 自定义钩子
 *
 */

/*
\Phpcmf\Hooks::on('cms_init', function() {
    // cms 初始化后的运行
});*/
