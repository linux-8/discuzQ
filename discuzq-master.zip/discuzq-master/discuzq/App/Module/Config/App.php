<?php

return [

    'type' => 'app',
    'name' => '内容系统',
    'author' => 'DiscuzQ应用',
    'icon' => 'fa fa-th-large',

];