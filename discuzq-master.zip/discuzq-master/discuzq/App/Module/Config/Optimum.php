<?php

return [

    'category_list_count' => 0, // 0 不统计， 1 统计
    'category_cache_field' => [

    ], // 栏目缓存字段


];