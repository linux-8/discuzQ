DROP TABLE IF EXISTS `{dbprefix}urlrule`;
DROP TABLE IF EXISTS `{dbprefix}module`;