<?php

return [

    'id' => '1',
    'vip' => '1',
    'version' => '1.0.0',
    'license' => '',
    'updatetime' => '2023-08-15 09:18:31',
    'downtime' => '2023-08-15 17:20:16',

];
