<?php namespace Phpcmf\Controllers\Admin;


class Module_param extends \Phpcmf\Common
{

    public function index() {



    }


}
