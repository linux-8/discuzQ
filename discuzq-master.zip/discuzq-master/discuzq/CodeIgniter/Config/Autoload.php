<?php namespace Config;
/**
 * {{discuzq.cc}}
 * {{discuzq开源社区框架系统}}
 * 作者：张安冠。 本文件是框架系统文件，二次开发时不可以修改本文件
 **/

use CodeIgniter\Config\AutoloadConfig;

class Autoload extends AutoloadConfig
{
	public $psr4 = [];

	public $classmap = [];
	
	public $files = [];

	//--------------------------------------------------------------------

	public function __construct()
	{
		parent::__construct();
		$this->psr4 = array_merge($this->psr4, [

            'App'                           => COREPATH,
            'Config'                        => FRAMEPATH.'Config',

        ]);
	}
}
